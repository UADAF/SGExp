//------------------------------------------------------------------------------------------------
//
//   SG Craft - 3rd Party Mod Integration Base Class
//
//------------------------------------------------------------------------------------------------

package gcewing.sg;

public class IntegrationBase extends BaseSubsystem {

//     protected SGCraft mod = SGCraft.mod;

    public void onServerTick() {
    }

}
