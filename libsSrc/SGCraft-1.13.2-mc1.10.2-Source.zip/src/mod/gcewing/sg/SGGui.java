//------------------------------------------------------------------------------------------------
//
//   SG Craft - GUI numbers
//
//------------------------------------------------------------------------------------------------

package gcewing.sg;

public enum SGGui {
    SGBase, SGController, DHDFuel, /*IC2*/PowerUnit, OCInterface;
}
