//------------------------------------------------------------------------------------------------
//
//   SG Craft - Third-party mod integration
//
//------------------------------------------------------------------------------------------------

package gcewing.sg;

public interface IIntegration {

    public void onServerTick();

}
