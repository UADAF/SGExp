//------------------------------------------------------------------------------------------------
//
//   SG Craft - Iris Renderer
//
//------------------------------------------------------------------------------------------------

package gcewing.sg;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.entity.*;
import net.minecraft.tileentity.*;
import net.minecraft.world.*;
import net.minecraft.util.*;

public class IrisRenderer extends BaseEntityRenderer<IrisEntity> {

    @Override
    public void renderEntity(IrisEntity entity, double x, double y, double z, float yaw, float dt) {
    }

}
