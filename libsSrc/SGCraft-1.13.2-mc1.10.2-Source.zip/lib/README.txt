For building with Gradle, dependency jar files must be placed here.
See ../BUILDING.txt for a list of required files.
